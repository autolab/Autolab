require "AssessmentBase.rb"

module HomewOrk02
  include AssessmentBase

  def assessmentInitialize(course)
    super("homework0",course)
    @problems = []
  end

end
