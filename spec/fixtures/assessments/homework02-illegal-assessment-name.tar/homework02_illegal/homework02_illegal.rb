require "AssessmentBase.rb"

module Homework02Illegal
  include AssessmentBase

  def assessmentInitialize(course)
    super("homework0",course)
    @problems = []
  end

end
