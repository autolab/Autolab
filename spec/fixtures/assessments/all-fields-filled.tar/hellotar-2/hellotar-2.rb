require "AssessmentBase.rb"

module Hellotar222
  include AssessmentBase

  def assessmentInitialize(course)
    super("hellotar-2",course)
    @problems = []
  end

end
