require "AssessmentBase.rb"

module Homework0
  include AssessmentBase

  def assessmentInitialize(course)
    super("homework0",course)
    @problems = []
  end

end
