# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
#
# REMOVE secret_token when we're at Rails 4
Autolab3::Application.config.secret_token = 'f3744b24bb9b3f293159ae01a74a3710ba0af8a435386701bd90c198bd424e9a989c0850cfcc9349192a5a1c64c06cda70ff27b17081690aa8d4a7985e10aedb'
Autolab3::Application.config.secret_key_base = 'xxxf3744b24bb9b3f293159ae01a74a3710ba0af8a435386701bd90c198bd424e9a989c0850cfcc9349192a5a1c64c06cda70ff27b17081690aa8d4a7985e10aedb'
