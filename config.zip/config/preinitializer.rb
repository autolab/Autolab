require "rubygems"
Gem::Deprecate.skip = true
