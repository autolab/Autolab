from handin import *

def main():
    if (adder(1, 1) == 2):
        print("{scores: {autograded:100}}")
    else:
        print("{scores: {autograded:0}}")

if __name__ == '__main__':
    main()
