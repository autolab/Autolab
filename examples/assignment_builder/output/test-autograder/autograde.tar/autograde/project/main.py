import sys


# return your name
def get_name():
    return "Batman"


# return your age
def get_age():
    return 30


if __name__ == "__main__":
    name = get_name()
    age = get_age()
