import sys


# return your name
def get_name():
    


# return your age
def get_age():
    


if __name__ == "__main__":
    name = get_name()
    age = get_age()
